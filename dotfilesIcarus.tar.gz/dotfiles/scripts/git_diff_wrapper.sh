#!/bin/bash -
#===============================================================================
#
#          FILE: git_diff_wrapper.sh
#
#         USAGE: ./git_diff_wrapper.sh
#
#   DESCRIPTION:
#
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: John Warnes (), johnwarnes@mail.weber.edu
#  ORGANIZATION: WSU
#       CREATED: 06/03/2017 06:36:50 PM
#      REVISION:  ---
#===============================================================================

vimdiff "$2" "$5"
