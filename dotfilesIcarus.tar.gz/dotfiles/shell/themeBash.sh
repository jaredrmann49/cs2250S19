# echo -ne "\e[2 q"    # block cursor

echo -ne "\e[6 q"  # line cursor
